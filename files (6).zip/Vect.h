#pragma once
#include <iostream>
#include <stdexcept>

// Власний клас виняткової ситуації для Vect
class VectException : public std::exception {
private:
    std::string message;
public:
    explicit VectException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override {
        return message.c_str();
    }
};

class Vect {
public:
    // Конструктор: приймає unsigned char, щоб уникнути overflow (виправлення помилки)
    explicit Vect(unsigned char n);

    // Деструктор з обробкою виняткових ситуацій
    ~Vect();

    // Оператор індексування з перевіркою меж
    int& operator[](int i);

    // Вивід елементів масиву
    void Print() const;

    // Розмір масиву
    unsigned char Size() const { return size; }

private:
    int* p;
    unsigned char size;  // ВИПРАВЛЕНО: signed char -> unsigned char

    // Допоміжний метод для безпечного звільнення пам'яті (для деструктора)
    void Destroy();
};
