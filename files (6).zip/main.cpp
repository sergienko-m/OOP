#include <iostream>
#include <stdexcept>
#include "Vect.h"

// ================================================================
// Завдання 1: Демонстрація помилки оригінального коду
// (char size отримує -56 замість 200 → new повертає nullptr)
// ================================================================
void task1_original_bug_demo() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "ЗАВДАННЯ 1: Аналіз помилки оригінального коду" << std::endl;
    std::cout << "========================================" << std::endl;

    // Демонстрація: char і 200
    signed char sc = static_cast<signed char>(200);
    unsigned char uc = static_cast<unsigned char>(200);

    std::cout << "signed char(200)   = " << static_cast<int>(sc)
              << "  ← ПОМИЛКА: від'ємне!" << std::endl;
    std::cout << "unsigned char(200) = " << static_cast<int>(uc)
              << "  ← ПРАВИЛЬНО" << std::endl;
    std::cout << "\nПояснення: 200 = 0xC8 = 11001000b."
                 " У signed char старший біт = знак → -56." << std::endl;
    std::cout << "Тому new int[-56] повертає nullptr і конструктор виводив помилку." << std::endl;
}

// ================================================================
// Завдання 2: Виправлений код з перехопленням помилок
// ================================================================
void task2_fixed_with_exceptions() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "ЗАВДАННЯ 2: Виправлений код + try/catch/throw" << std::endl;
    std::cout << "========================================" << std::endl;

    // --- 2а: Нормальна робота ---
    std::cout << "\n--- 2а: Нормальна робота (розмір = 3) ---" << std::endl;
    try {
        Vect a(3);
        a[0] = 0;
        a[1] = 1;
        a[2] = 2;
        std::cout << "Вектор a: ";
        a.Print();
    }
    catch (const VectException& e) {
        std::cerr << "VectException: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Невідома помилка!" << std::endl;
    }

    // --- 2б: Розмір 200 — тепер працює коректно (unsigned char) ---
    std::cout << "\n--- 2б: Розмір 200 (раніше давав помилку, тепер OK) ---" << std::endl;
    try {
        Vect a1(200);
        a1[10] = 5;
        std::cout << "Вектор a1 (перші 15 елементів): [ ";
        for (int i = 0; i < 15; ++i) {
            std::cout << a1[i];
            if (i < 14) std::cout << ", ";
        }
        std::cout << ", ... ]" << std::endl;
    }
    catch (const VectException& e) {
        std::cerr << "VectException: " << e.what() << std::endl;
    }
    catch (const std::out_of_range& e) {
        std::cerr << "out_of_range: " << e.what() << std::endl;
    }

    // --- 2в: Вихід за межі масиву ---
    std::cout << "\n--- 2в: Вихід за межі масиву (індекс 100 для розміру 3) ---" << std::endl;
    try {
        Vect b(3);
        b[0] = 10;
        b[100] = 99;  // ← має кинути std::out_of_range
    }
    catch (const std::out_of_range& e) {
        std::cerr << "ПЕРЕХОПЛЕНО out_of_range: " << e.what() << std::endl;
    }
    catch (const VectException& e) {
        std::cerr << "ПЕРЕХОПЛЕНО VectException: " << e.what() << std::endl;
    }

    // --- 2г: Розмір 0 ---
    std::cout << "\n--- 2г: Розмір 0 (некоректний розмір) ---" << std::endl;
    try {
        Vect c(0);  // ← має кинути VectException
    }
    catch (const VectException& e) {
        std::cerr << "ПЕРЕХОПЛЕНО VectException: " << e.what() << std::endl;
    }
}

// ================================================================
// Завдання 3: Обробка виняткових ситуацій у конструкторі та деструкторі
// ================================================================

// Демонстрація catch(...) — перехоплення всіх типів
void xhandler(int test) {
    try {
        if (test != 0)
            throw test;
        else
            throw std::string("Значення дорівнює нулю");
    }
    catch (int i) {
        std::cout << "  catch(int): перехоплено число = " << i << std::endl;
    }
    catch (const std::string& s) {
        std::cout << "  catch(string): перехоплено рядок = \"" << s << "\"" << std::endl;
    }
    catch (...) {
        std::cout << "  catch(...): перехоплено невідомий тип" << std::endl;
    }
}

void task3_constructor_destructor_exceptions() {
    std::cout << "\n========================================" << std::endl;
    std::cout << "ЗАВДАННЯ 3: Виняткові ситуації в конструкторі та деструкторі" << std::endl;
    std::cout << "========================================" << std::endl;

    // --- 3а: Демонстрація перехоплення різних типів (з теорії) ---
    std::cout << "\n--- 3а: catch різних типів (Приклад 2 з теорії) ---" << std::endl;
    for (int i = 0; i <= 3; ++i) {
        std::cout << "xhandler(" << i << "):" << std::endl;
        xhandler(i);
    }

    // --- 3б: Деструктор успішно обробляє виняток всередині себе ---
    std::cout << "\n--- 3б: Деструктор з обробкою помилок ---" << std::endl;
    {
        // Блок: при виході Vect::~Vect() викличе Destroy()
        // та перехопить будь-який виняток усередині
        std::cout << "Створення об'єкта у внутрішньому блоці..." << std::endl;
        try {
            Vect v(5);
            v[0] = 100;
            v[1] = 200;
            std::cout << "Вектор v: ";
            v.Print();
            std::cout << "Вихід з блоку → виклик деструктора:" << std::endl;
        }
        catch (const VectException& e) {
            std::cerr << "VectException: " << e.what() << std::endl;
        }
    }

    // --- 3в: catch(...) як "перехоплювач усього" ---
    std::cout << "\n--- 3в: catch(...) перехоплює все ---" << std::endl;
    try {
        Vect d(10);
        d[5] = 42;
        throw 3.14;  // кидаємо double — немає конкретного catch для нього
    }
    catch (const VectException& e) {
        std::cerr << "VectException: " << e.what() << std::endl;
    }
    catch (const std::out_of_range& e) {
        std::cerr << "out_of_range: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "catch(...): перехоплено невідомий виняток (наприклад, double 3.14)" << std::endl;
    }
}

// ================================================================
// main
// ================================================================
int main() {
    std::cout << "============================================" << std::endl;
    std::cout << "  Лабораторна робота 2.3 — Exception Handling" << std::endl;
    std::cout << "============================================" << std::endl;

    task1_original_bug_demo();
    task2_fixed_with_exceptions();
    task3_constructor_destructor_exceptions();

    std::cout << "\n========================================" << std::endl;
    std::cout << "Програма завершена успішно." << std::endl;
    std::cout << "========================================" << std::endl;

    return 0;
}
