/*
 * Лабораторна робота — Параметричний поліморфізм
 * Тема: Віртуальні функції. Динамічний поліморфізм.
 *
 * Клас Chislo (базовий) — зберігає ціле додатне число (long),
 *   містить віртуальну функцію factorial().
 * Клас Matrix (похідний) — масив 100 цілих чисел,
 *   розмірність = число з базового класу.
 *   Віртуальна функція НЕ перевизначається (використовується з базового).
 */

#include <iostream>
#include <iomanip>
using namespace std;

// ============================================================
//  Базовий клас Chislo
// ============================================================
class Chislo {
private:
    long number;   // ціле додатне число (розмірність масиву)

public:
    // Конструктор
    Chislo(long n = 0) : number(n) {
        cout << "[Chislo] Конструктор: number = " << number << endl;
    }

    // Деструктор
    virtual ~Chislo() {
        cout << "[Chislo] Деструктор" << endl;
    }

    // Гетер
    long getNumber() const { return number; }

    // Сетер
    void setNumber(long n) { number = n; }

    // Віртуальна функція — обчислює факторіал параметра
    virtual long factorial(long n) {
        if (n < 0) return -1;   // некоректне значення
        long result = 1;
        for (long i = 2; i <= n; i++) result *= i;
        return result;
    }
};

// ============================================================
//  Похідний клас Matrix
// ============================================================
class Matrix : public Chislo {
public:
    int arr[100];   // масив 100 цілих додатних чисел

    // Конструктор
    Matrix(long n = 0) : Chislo(n) {
        for (int i = 0; i < 100; i++) arr[i] = 0;
        cout << "[Matrix] Конструктор: розмірність = " << n << endl;
    }

    // Деструктор
    ~Matrix() {
        cout << "[Matrix] Деструктор" << endl;
    }

    // Введення масиву з клавіатури
    void inputArray() {
        long size = getNumber();
        cout << "Введіть " << size << " цілих додатних чисел:" << endl;
        for (long i = 0; i < size; i++) {
            cout << "  arr[" << i << "] = ";
            cin >> arr[i];
            while (arr[i] < 0) {
                cout << "  Число має бути додатним! arr[" << i << "] = ";
                cin >> arr[i];
            }
        }
    }

    // Виведення таблиці факторіалів
    // Використовує inherited factorial() з базового класу (не перевизначена!)
    void printFactorialTable() {
        long size = getNumber();
        cout << "\n+--------+--------+---------------------+" << endl;
        cout << "| Індекс |  Число |           Факторіал |" << endl;
        cout << "+--------+--------+---------------------+" << endl;
        for (long i = 0; i < size; i++) {
            long fact = factorial(arr[i]);   // виклик БАЗОВОЇ virtual factorial()
            cout << "| " << setw(6) << i
                 << " | " << setw(6) << arr[i]
                 << " | " << setw(19) << fact << " |" << endl;
        }
        cout << "+--------+--------+---------------------+" << endl;
    }
};

// ============================================================
//  main()
// ============================================================
int main() {
    // --- 1. Демонстрація базового класу ---
    cout << "=== 1. Базовий клас Chislo ===" << endl;
    Chislo ch(5);
    cout << "factorial(5) через об'єкт Chislo = " << ch.factorial(5) << endl;
    cout << "factorial(0) = " << ch.factorial(0) << endl;
    cout << "factorial(1) = " << ch.factorial(1) << endl;

    // --- 2. Робота з вказівником на базовий клас ---
    cout << "\n=== 2. Вказівник на базовий клас ===" << endl;
    Chislo* p;

    // Вказівник на базовий об'єкт
    p = &ch;
    cout << "p->factorial(6) [базовий об'єкт] = " << p->factorial(6) << endl;

    // --- 3. Введення розмірності та масиву ---
    cout << "\n=== 3. Клас Matrix ===" << endl;
    long n;
    cout << "Введіть розмірність масиву (1-20): ";
    cin >> n;
    while (n < 1 || n > 20) {
        cout << "Введіть число від 1 до 20: ";
        cin >> n;
    }

    Matrix mat(n);
    mat.inputArray();

    // --- 4. Вказівник на базовий клас, що вказує на Matrix ---
    cout << "\n=== 4. Вказівник базового класу -> Matrix ===" << endl;
    p = &mat;   // вказівник базового класу вказує на похідний об'єкт

    // Виклик factorial() через вказівник базового класу
    // Оскільки в Matrix функція НЕ перевизначена — викликається базова версія
    cout << "p->factorial(5) через вказівник [базова версія] = "
         << p->factorial(5) << endl;
    cout << "(Matrix не перевизначає factorial — використовується Chislo::factorial)" << endl;

    // --- 5. Таблиця факторіалів ---
    cout << "\n=== 5. Таблиця факторіалів масиву ===" << endl;
    mat.printFactorialTable();

    // --- 6. Аналіз: перевизначення відсутнє ---
    cout << "\n=== 6. Аналіз результату ===" << endl;
    cout << "Оскільки Matrix не перевизначає factorial()," << endl;
    cout << "при виклику через вказівник базового класу" << endl;
    cout << "завжди виконується версія Chislo::factorial()." << endl;
    cout << "Це підтверджує ієрархічний порядок успадкування" << endl;
    cout << "віртуальних функцій у C++." << endl;

    return 0;
}
