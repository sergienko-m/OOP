// Лабораторна робота 2.4
// Проектування і опрацювання програми з власними маніпуляторами
// і власними функціями введення-виведення

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <cfloat>
#include <string>
using namespace std;

class MathFunction {
    double* x;
    double* y;
    int size;

    void alloc(int n) {
        delete[] x; delete[] y;
        size = n;
        x = new double[n]();
        y = new double[n]();
    }

public:
    MathFunction() : x(nullptr), y(nullptr), size(0) {}
    ~MathFunction() { delete[] x; delete[] y; }

    int getSize() const { return size; }
    double getX(int i) const { return x[i]; }
    double getY(int i) const { return y[i]; }

    friend ostream& operator<<(ostream& stream, const MathFunction& f);
    friend void readTwoFunctions(const char* filename, MathFunction& f1, MathFunction& f2);
    friend void findMinMax(const MathFunction& f1, const MathFunction& f2);
    friend void writeFormatted(const MathFunction& f1, const MathFunction& f2, const char* outFile);
};

ostream& operator<<(ostream& stream, const MathFunction& f) {
    ios_base::fmtflags oldFlags = stream.flags();
    streamsize oldPrec = stream.precision();
    stream << fixed << setprecision(3);

    stream << "+-----------+-----------+\n";
    stream << "|     X     |     Y     |\n";
    stream << "+-----------+-----------+\n";
    for (int i = 0; i < f.size; i++)
        stream << "| " << setw(9) << f.x[i] << " | " << setw(9) << f.y[i] << " |\n";
    stream << "+-----------+-----------+\n";

    const int W = 60, H = 20;
    double xMin = f.x[0], xMax = f.x[f.size-1];
    double yMin = DBL_MAX, yMax = -DBL_MAX;
    for (int i = 0; i < f.size; i++) {
        if (f.y[i] < yMin) yMin = f.y[i];
        if (f.y[i] > yMax) yMax = f.y[i];
    }
    if (yMin == yMax) { yMin -= 1; yMax += 1; }

    char grid[H][W+1];
    for (int r = 0; r < H; r++) { for (int c = 0; c < W; c++) grid[r][c] = ' '; grid[r][W] = '\0'; }

    int axisRow = (int)((yMax/(yMax-yMin))*(H-1));
    if (axisRow < 0) axisRow = 0; if (axisRow >= H) axisRow = H-1;
    for (int c = 0; c < W; c++) grid[axisRow][c] = '-';

    int axisCol = (xMax != xMin) ? (int)((0.0-xMin)/(xMax-xMin)*(W-1)) : W/2;
    if (axisCol < 0) axisCol = 0; if (axisCol >= W) axisCol = W-1;
    for (int r = 0; r < H; r++) grid[r][axisCol] = '|';
    grid[axisRow][axisCol] = '+';

    for (int i = 0; i < f.size; i++) {
        int col = (xMax != xMin) ? (int)(((f.x[i]-xMin)/(xMax-xMin))*(W-1)) : W/2;
        int row = (int)(((yMax-f.y[i])/(yMax-yMin))*(H-1));
        if (col >= 0 && col < W && row >= 0 && row < H) grid[row][col] = '*';
    }

    stream << "\n  Графік функції:\n  Y\n";
    for (int r = 0; r < H; r++) stream << "  " << grid[r] << "\n";
    stream << "  " << string(W,' ') << " X\n\n";

    stream.flags(oldFlags); stream.precision(oldPrec);
    return stream;
}

void readTwoFunctions(const char* filename, MathFunction& f1, MathFunction& f2) {
    ifstream fin(filename);
    if (!fin) { cerr << "Помилка: " << filename << "\n"; return; }
    int n = 0; double a,b,c;
    while (fin >> a >> b >> c) n++;
    fin.clear(); fin.seekg(0);
    f1.alloc(n); f2.alloc(n);
    for (int i = 0; i < n; i++) {
        fin >> f1.x[i] >> f1.y[i] >> f2.y[i];
        f2.x[i] = f1.x[i];
    }
    fin.close();
}

void findMinMax(const MathFunction& f1, const MathFunction& f2) {
    double minVal = DBL_MAX, maxVal = -DBL_MAX, minX = 0, maxX = 0;
    for (int i = 0; i < f1.size; i++) {
        if (f1.y[i] < minVal) { minVal = f1.y[i]; minX = f1.x[i]; }
        if (f1.y[i] > maxVal) { maxVal = f1.y[i]; maxX = f1.x[i]; }
    }
    for (int i = 0; i < f2.size; i++) {
        if (f2.y[i] < minVal) { minVal = f2.y[i]; minX = f2.x[i]; }
        if (f2.y[i] > maxVal) { maxVal = f2.y[i]; maxX = f2.x[i]; }
    }
    cout << fixed << setprecision(3);
    cout << "MIN: y = " << minVal << "  при x = " << minX << "\n";
    cout << "MAX: y = " << maxVal << "  при x = " << maxX << "\n";
}

void writeFormatted(const MathFunction& f1, const MathFunction& f2, const char* outFile) {
    ofstream fout(outFile);
    if (!fout) { cerr << "Помилка запису: " << outFile << "\n"; return; }
    fout << fixed << setprecision(3);
    for (int i = 0; i < f1.size; i++) {
        double xi = f1.x[i];
        if (xi == (double)(int)xi)
            fout << showpos << setw(10) << xi << noshowpos;
        else
            fout << setw(10) << xi;
        fout << "\t" << setw(10) << f1.y[i]
             << "\t" << setw(10) << f2.y[i] << "\n";
    }
    fout.close();
    cout << "Форматований файл збережено: " << outFile << "\n";
}

// Власні маніпулятори
ostream& hexMode(ostream& s) { s.setf(ios::hex|ios::showbase, ios::basefield); return s; }
ostream& decMode(ostream& s) { s.setf(ios::dec, ios::basefield); s.unsetf(ios::showbase); return s; }
ostream& sciFixed(ostream& s) { s.setf(ios::fixed); s.precision(4); return s; }

void demoManipulators() {
    cout << "\n=== Власні маніпулятори ===\n";
    cout << "255 у HEX:  " << hexMode << 255 << "\n";
    cout << "255 у DEC:  " << decMode << 255 << "\n";
    cout << "Pi (fixed): " << sciFixed << 3.14159265 << "\n";

    cout << "\n=== setf / unsetf ===\n";
    cout.setf(ios::uppercase|ios::showbase|ios::hex, ios::basefield);
    cout << "88 у HEX: " << 88 << "\n";
    cout.unsetf(ios::uppercase);
    cout << "88 у hex: " << 88 << "\n";
    cout.setf(ios::dec, ios::basefield); cout.unsetf(ios::showbase|ios::fixed);
    cout.precision(6);

    cout << "\n=== width / fill / precision ===\n";
    cout.width(14); cout.fill('*'); cout.setf(ios::fixed); cout.precision(3);
    cout << 3.14159 << "\n";
    cout.fill(' '); cout.unsetf(ios::fixed); cout.precision(6);
}

int main() {
    const char* inFile  = "data.txt";
    const char* outFile = "formatted.txt";

    { // Створення вхідного файлу
        ofstream init(inFile);
        for (int i = -5; i <= 5; i++)
            init << (double)i << " " << sin((double)i) << " " << cos((double)i) << "\n";
    }
    cout << "Файл " << inFile << " створено (x, sin(x), cos(x)).\n";

    MathFunction func1, func2;
    readTwoFunctions(inFile, func1, func2);

    cout << "\n=== Функція 1: sin(x) ===\n"; cout << func1;
    cout << "\n=== Функція 2: cos(x) ===\n"; cout << func2;

    cout << "\n=== Min/Max по обох функціях ===\n";
    findMinMax(func1, func2);

    cout << "\n=== Форматований файл ===\n";
    writeFormatted(func1, func2, outFile);
    { // Показуємо перші 3 рядки
        ifstream fin(outFile); string line; int cnt = 0;
        while (getline(fin,line) && cnt++ < 3) cout << "  |" << line << "|\n";
    }

    demoManipulators();
    return 0;
}
