#ifndef BtnNClickH
#define BtnNClickH

#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>

// ============================================================
// Клас TBtnNClick — нащадок TButton
// Лічить кількість натискань і відображає її у написі кнопки
// ============================================================
class PACKAGE TBtnNClick : public TButton
{
private:
    int NClick; // Лічильник натискань (прихований від користувача)

protected:

public:
    __fastcall TBtnNClick(TComponent* Owner);
    DYNAMIC void __fastcall Click(void);

__published:
};

#endif
