#include <vcl.h>
#pragma hdrstop

#include "BtnNClick.cpp" // підключаємо модуль нового компонента
#include "Unit1.h"

#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}

TBtnNClick *Btn; // динамічна змінна — об'єкт нового компонента

// Обробник кнопки "Створити нову кнопку":
// динамічно створює TBtnNClick і розміщує на формі
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    Btn = new TBtnNClick(Form1);
    Btn->Parent = Form1;
    Btn->Left   = 70;
    Btn->Top    = 100;
    Btn->Width  = 200;
    Btn->Height = 30;
}
