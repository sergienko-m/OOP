#include <vcl.h>
#pragma hdrstop

#include "SG.h"
#pragma package(smart_init)

// Запобігає розміщенню у класі суто віртуальних функцій
static inline void ValidCtrCheck(TSG *)
{
    new TSG(NULL);
}

// Конструктор: встановлює початкове значення прапорця
__fastcall TSG::TSG(TComponent* Owner)
    : TStringGrid(Owner)
{
    flag = true;
}

// Перекрита подія Click (клацання ЛКМ):
// перемикає розмір шрифту всіх комірок удвічі більше / менше
void __fastcall TSG::Click()
{
    if (flag)
        Font->Size = Font->Size * 2; // збільшити вдвічі
    else
        Font->Size = Font->Size / 2; // повернути до початкового

    flag = !flag;
    TStringGrid::Click();
}

// Перекрита подія KeyDown:
//   F11  → заповнити комірки випадковими числами 0..20
//   Esc  → очистити всі комірки
void __fastcall TSG::KeyDown(Word &Key, Classes::TShiftState Shift)
{
    if (Key == VK_ESCAPE)
    {
        for (int i = 0; i < RowCount; i++)
            for (int j = 0; j < ColCount; j++)
                Cells[j][i] = "";
    }

    if (Key == VK_F11)
    {
        for (int i = 0; i < RowCount; i++)
            for (int j = 0; j < ColCount; j++)
                Cells[j][i] = IntToStr(random(21)); // 0..20 включно
    }

    TStringGrid::KeyDown(Key, Shift);
}

// Реєстрація компонента на сторінці "Samples" палітри C++ Builder
namespace Sg
{
    void __fastcall PACKAGE Register()
    {
        TComponentClass classes[1] = { __classid(TSG) };
        RegisterComponents("Samples", classes, 0);
    }
}
