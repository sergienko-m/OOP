#include <vcl.h>
#pragma hdrstop

#include "SG.cpp" // підключаємо модуль нового компонента
#include "Unit1.h"

#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}

TSG *SGt; // динамічна змінна — об'єкт нового компонента

// Обробник кнопки "Відобразити компонент":
// динамічно створює TSG з таблицею 4 рядки × 5 стовпців
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    SGt = new TSG(Form1);
    SGt->Parent    = Form1;
    SGt->Left      = 20;
    SGt->Top       = 10;
    SGt->FixedRows = 0;
    SGt->FixedCols = 0;
    SGt->RowCount  = 4;
    SGt->ColCount  = 5;
    SGt->Options << goEditing << goTabs;
}
