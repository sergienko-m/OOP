#include <vcl.h>
#pragma hdrstop

#include "BtnNClick.h"
#pragma package(smart_init)

// Запобігає розміщенню у класі суто віртуальних функцій
static inline void ValidCtrCheck(TBtnNClick *)
{
    new TBtnNClick(NULL);
}

// Конструктор: ініціалізує лічильник нулем
__fastcall TBtnNClick::TBtnNClick(TComponent* Owner)
    : TButton(Owner)
{
    NClick = 0;
}

// Перекрита подія Click:
// збільшує лічильник і відображає кількість натискань на кнопці
void __fastcall TBtnNClick::Click(void)
{
    NClick++;
    Caption = Name + " (" + IntToStr(NClick) + ") клацань";
    TButton::Click(); // зберігаємо стандартну поведінку батьківського класу
}

// Реєстрація компонента на сторінці "MyClasses" палітри C++ Builder
namespace Btnnclick
{
    void __fastcall PACKAGE Register()
    {
        TComponentClass classes[1] = { __classid(TBtnNClick) };
        RegisterComponents("MyClasses", classes, 0);
    }
}
