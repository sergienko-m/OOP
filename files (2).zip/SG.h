#ifndef SGH
#define SGH

#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <Grids.hpp>

// ============================================================
// Клас TSG — нащадок TStringGrid
// Додаткові можливості:
//   F11  — заповнити комірки випадковими числами (0..20)
//   Esc  — очистити всі комірки
//   ЛКМ  — збільшити / зменшити розмір шрифту вдвічі
// ============================================================
class PACKAGE TSG : public TStringGrid
{
private:
    bool flag; // прапорець стану шрифту: true = збільшити, false = зменшити

protected:

public:
    __fastcall TSG(TComponent* Owner);
    DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
    DYNAMIC void __fastcall Click(void);

__published:
};

#endif
