/*
 * Лабораторна робота №10 — Шаблони
 * Завдання №9: Шаблонний клас СТЕК на статичному масиві вказівників
 *
 * Операції:
 *   - push()    — занесення елементу в стек
 *   - pop()     — вилучення значення з верхівки стеку
 *   - peek()    — перегляд верхівки без вилучення
 *   - display() — виведення всіх значень стеку на екран
 *   - size()    — повернення кількості елементів стеку
 *   - isEmpty() — перевірка на порожність
 *   - isFull()  — перевірка на заповненість
 */

#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

// ============================================================
//  Шаблонний клас Stack
// ============================================================
template <class T, int MAX_SIZE = 10>
class Stack {
private:
    T* data[MAX_SIZE];   // статичний масив вказівників на елементи
    int top;             // індекс верхівки (-1 якщо порожній)

public:
    // Конструктор
    Stack() : top(-1) {}

    // Деструктор — звільняє динамічно виділену пам'ять
    ~Stack() {
        while (top >= 0) {
            delete data[top];
            top--;
        }
    }

    // Занесення елементу в стек
    void push(const T& value) {
        if (isFull()) {
            throw overflow_error("Stack overflow: стек заповнений!");
        }
        data[++top] = new T(value);
    }

    // Вилучення значення з верхівки стеку
    T pop() {
        if (isEmpty()) {
            throw underflow_error("Stack underflow: стек порожній!");
        }
        T value = *data[top];
        delete data[top];
        data[top] = nullptr;
        top--;
        return value;
    }

    // Перегляд верхівки без вилучення
    T peek() const {
        if (isEmpty()) {
            throw underflow_error("Stack is empty: стек порожній!");
        }
        return *data[top];
    }

    // Виведення всіх значень стеку на екран (від верхівки до дна)
    void display() const {
        if (isEmpty()) {
            cout << "[порожній стек]" << endl;
            return;
        }
        cout << "Стек (верхівка -> дно): ";
        for (int i = top; i >= 0; i--) {
            cout << *data[i];
            if (i > 0) cout << " -> ";
        }
        cout << endl;
    }

    // Повернення кількості елементів стеку
    int size() const {
        return top + 1;
    }

    // Перевірка на порожність
    bool isEmpty() const {
        return top == -1;
    }

    // Перевірка на заповненість
    bool isFull() const {
        return top == MAX_SIZE - 1;
    }
};

// ============================================================
//  Допоміжна функція — роздільник у виводі
// ============================================================
void printSeparator(const string& title) {
    cout << "\n===== " << title << " =====" << endl;
}

// ============================================================
//  main() — демонстрація роботи шаблонного стеку
// ============================================================
int main() {
    // --- 1. Стек цілих чисел (int) ---
    printSeparator("Стек цілих чисел (int), MAX=5");
    Stack<int, 5> intStack;

    cout << "Додаємо елементи: 10, 20, 30, 40, 50" << endl;
    intStack.push(10);
    intStack.push(20);
    intStack.push(30);
    intStack.push(40);
    intStack.push(50);

    intStack.display();
    cout << "Кількість елементів: " << intStack.size() << endl;
    cout << "Верхівка (peek): " << intStack.peek() << endl;

    cout << "\nВилучаємо 2 елементи:" << endl;
    cout << "  pop() = " << intStack.pop() << endl;
    cout << "  pop() = " << intStack.pop() << endl;
    intStack.display();
    cout << "Кількість елементів: " << intStack.size() << endl;

    // --- 2. Стек дійсних чисел (double) ---
    printSeparator("Стек дійсних чисел (double), MAX=10");
    Stack<double> doubleStack;

    cout << "Додаємо елементи: 3.14, 2.71, 1.41, 1.73" << endl;
    doubleStack.push(3.14);
    doubleStack.push(2.71);
    doubleStack.push(1.41);
    doubleStack.push(1.73);

    doubleStack.display();
    cout << "Кількість елементів: " << doubleStack.size() << endl;

    cout << "\nВилучаємо всі елементи:" << endl;
    while (!doubleStack.isEmpty()) {
        cout << "  pop() = " << doubleStack.pop() << endl;
    }
    doubleStack.display();

    // --- 3. Стек рядків (string) ---
    printSeparator("Стек рядків (string), MAX=5");
    Stack<string, 5> stringStack;

    cout << "Додаємо елементи: \"C++\", \"Templates\", \"OOP\", \"Stack\"" << endl;
    stringStack.push("C++");
    stringStack.push("Templates");
    stringStack.push("OOP");
    stringStack.push("Stack");

    stringStack.display();
    cout << "Кількість елементів: " << stringStack.size() << endl;
    cout << "Верхівка (peek): " << stringStack.peek() << endl;

    cout << "\nВилучаємо 2 елементи:" << endl;
    cout << "  pop() = " << stringStack.pop() << endl;
    cout << "  pop() = " << stringStack.pop() << endl;
    stringStack.display();

    // --- 4. Стек символів (char) ---
    printSeparator("Стек символів (char), MAX=5");
    Stack<char, 5> charStack;

    cout << "Додаємо символи: A, B, C, D" << endl;
    charStack.push('A');
    charStack.push('B');
    charStack.push('C');
    charStack.push('D');

    charStack.display();
    cout << "Кількість елементів: " << charStack.size() << endl;

    // --- 5. Демонстрація обробки виключень ---
    printSeparator("Обробка виключень");

    // Спроба вилучити з порожнього стеку
    try {
        Stack<int, 3> emptyStack;
        cout << "Спроба pop() з порожнього стеку:" << endl;
        emptyStack.pop();
    } catch (const underflow_error& e) {
        cout << "  [Виключення] " << e.what() << endl;
    }

    // Спроба додати понад ліміт
    try {
        Stack<int, 3> smallStack;
        cout << "\nСпроба push() понад MAX_SIZE=3:" << endl;
        smallStack.push(1);
        smallStack.push(2);
        smallStack.push(3);
        smallStack.push(4); // тут має викинути виключення
    } catch (const overflow_error& e) {
        cout << "  [Виключення] " << e.what() << endl;
    }

    cout << "\n=== Програму завершено успішно ===" << endl;
    return 0;
}
