/*
 * Лабораторна робота — Шаблони. Параметричний поліморфізм
 * Завдання: Шаблонний клас розрідженого одновимірного масиву
 *
 * Структура:
 *   - Element<T>      — один елемент фізичного масиву (індекс + значення)
 *   - SparseArray<T>  — розріджений масив на базі std::list
 *
 * Операції:
 *   - operator[]  — індексування (пошук або створення елемента)
 *   - operator=   — присвоєння
 *   - show()      — виведення вмісту масиву
 *   - size()      — кількість збережених елементів
 */

#include <iostream>
#include <list>
#include <string>
using namespace std;

// ============================================================
//  Клас Element<T> — один елемент фізичного масиву
// ============================================================
template <class T>
class Element {
public:
    int   index;   // логічний індекс
    T     value;   // значення елемента

    // Конструктор за замовчуванням
    Element() : index(0), value(T()) {}

    // Конструктор з параметрами
    Element(int idx, const T& val) : index(idx), value(val) {}
};

// ============================================================
//  Клас SparseArray<T> — розріджений масив
// ============================================================
template <class T>
class SparseArray {
private:
    int               logicalSize;  // розмір логічного масиву
    list<Element<T>>  data;         // фізичний масив (двозв'язний список)

public:
    // --- Конструктор за замовчуванням ---
    SparseArray() : logicalSize(0) {}

    // --- Конструктор з розміром ---
    explicit SparseArray(int size) : logicalSize(size) {}

    // --- Конструктор копіювання ---
    SparseArray(const SparseArray<T>& other)
        : logicalSize(other.logicalSize), data(other.data) {}

    // --- Деструктор ---
    ~SparseArray() {
        data.clear();
    }

    // --- Операція присвоєння ---
    SparseArray<T>& operator=(const SparseArray<T>& other) {
        if (this != &other) {
            logicalSize = other.logicalSize;
            data = other.data;
        }
        return *this;
    }

    // --- Операція індексування operator[] ---
    // Якщо елемент з таким індексом знайдено — повертає посилання на нього.
    // Якщо не знайдено — створює новий елемент з дефолтним значенням.
    T& operator[](int idx) {
        if (idx < 0 || idx >= logicalSize) {
            throw out_of_range("Індекс виходить за межі логічного масиву!");
        }
        // Пошук елемента в списку
        for (auto& elem : data) {
            if (elem.index == idx) {
                return elem.value;
            }
        }
        // Елемент не знайдено — створюємо новий
        data.push_back(Element<T>(idx, T()));
        return data.back().value;
    }

    // --- Виведення вмісту масиву ---
    void show() const {
        if (data.empty()) {
            cout << "  [масив порожній — жодного елемента не збережено]" << endl;
            return;
        }
        cout << "  Збережені елементи (" << data.size()
             << " з " << logicalSize << " логічних):" << endl;
        for (const auto& elem : data) {
            cout << "    [" << elem.index << "] = " << elem.value << endl;
        }
    }

    // --- Кількість збережених елементів ---
    int size() const {
        return static_cast<int>(data.size());
    }

    // --- Розмір логічного масиву ---
    int logicalLength() const {
        return logicalSize;
    }
};

// ============================================================
//  Допоміжна функція — роздільник
// ============================================================
void separator(const string& title) {
    cout << "\n===== " << title << " =====" << endl;
}

// ============================================================
//  main() — демонстрація роботи
// ============================================================
int main() {

    // --- 1. Розріджений масив цілих чисел (int) ---
    separator("Розріджений масив int, логічний розмір = 10");

    SparseArray<int> arrInt(10);

    // Заповнюємо лише деякі елементи (розріджений масив)
    arrInt[0] = 100;
    arrInt[3] = 200;
    arrInt[7] = 300;
    arrInt[9] = 400;

    arrInt.show();
    cout << "  Збережено елементів: " << arrInt.size() << endl;
    cout << "  Логічний розмір:     " << arrInt.logicalLength() << endl;

    // Читання існуючого елемента
    cout << "\n  arrInt[3] = " << arrInt[3] << endl;

    // Читання неіснуючого — автоматично створюється
    cout << "  arrInt[5] (не існував) = " << arrInt[5] << endl;
    cout << "  Після звернення до [5]:" << endl;
    arrInt.show();

    // --- 2. Розріджений масив double ---
    separator("Розріджений масив double, логічний розмір = 20");

    SparseArray<double> arrDouble(20);
    arrDouble[1]  = 3.14;
    arrDouble[8]  = 2.71;
    arrDouble[15] = 1.41;

    arrDouble.show();

    // --- 3. Розріджений масив рядків (string) ---
    separator("Розріджений масив string, логічний розмір = 15");

    SparseArray<string> arrString(15);
    arrString[0]  = "Шаблони";
    arrString[4]  = "C++";
    arrString[10] = "Розріджений масив";
    arrString[14] = "STL list";

    arrString.show();

    // --- 4. Конструктор копіювання ---
    separator("Конструктор копіювання");

    SparseArray<int> arrCopy(arrInt);
    cout << "  Копія arrInt:" << endl;
    arrCopy.show();

    // Зміна копії не впливає на оригінал
    arrCopy[0] = 999;
    cout << "\n  Після arrCopy[0] = 999:" << endl;
    cout << "  Копія:" << endl;
    arrCopy.show();
    cout << "  Оригінал (незмінний):" << endl;
    arrInt.show();

    // --- 5. Операція присвоєння ---
    separator("Операція присвоєння (operator=)");

    SparseArray<double> arrAssigned(20);
    arrAssigned = arrDouble;
    cout << "  arrAssigned = arrDouble:" << endl;
    arrAssigned.show();

    // --- 6. Обробка виключення ---
    separator("Обробка виключення (вихід за межі)");

    try {
        cout << "  Спроба arrInt[100]..." << endl;
        arrInt[100] = 42;
    } catch (const out_of_range& e) {
        cout << "  [Виключення] " << e.what() << endl;
    }

    cout << "\n=== Програму завершено успішно ===" << endl;
    return 0;
}
